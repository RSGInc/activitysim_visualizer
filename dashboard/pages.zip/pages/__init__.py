"""Dashboard page modules."""
